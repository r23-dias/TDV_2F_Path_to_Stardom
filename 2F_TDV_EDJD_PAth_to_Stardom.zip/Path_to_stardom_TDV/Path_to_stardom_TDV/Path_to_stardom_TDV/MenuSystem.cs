﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Path_to_stardom_TDV
{
    public class MainMenu
    {
        private Texture2D _backgroundTexture;
        private BitmapFont _font;
        private string[] _menuOptions = { "NOVO JOGO", "CREDITOS", "SAIR" };
        private int _selectedOption = 0;
        private Vector2 _titlePosition;
        private Vector2[] _optionPositions;
        private Color _selectedColor = Color.Yellow;
        private Color _normalColor = Color.White;

        public void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            _font = new BitmapFont(graphicsDevice);
            _backgroundTexture = CreateMenuBackground(graphicsDevice);

            // Ajustar posições para tela de 1280x720
            _titlePosition = new Vector2(640 - 150, 150); // Centralizado horizontalmente

            _optionPositions = new Vector2[_menuOptions.Length];
            for (int i = 0; i < _menuOptions.Length; i++)
            {
                _optionPositions[i] = new Vector2(640 - 80, 350 + i * 60); // Centralizado
            }
        }

        private Texture2D CreateMenuBackground(GraphicsDevice graphicsDevice)
        {
            Texture2D texture = new Texture2D(graphicsDevice, 1280, 720);
            Color[] colorData = new Color[1280 * 720];

            for (int y = 0; y < 720; y++)
            {
                for (int x = 0; x < 1280; x++)
                {
                    float gradient = (float)y / 720f;
                    Color topColor = new Color(10, 10, 30);
                    Color bottomColor = new Color(50, 50, 100);
                    colorData[y * 1280 + x] = Color.Lerp(topColor, bottomColor, gradient);
                }
            }

            texture.SetData(colorData);
            return texture;
        }

        public int Update(KeyboardState currentKeyboard, KeyboardState previousKeyboard)
        {
            if (currentKeyboard.IsKeyDown(Keys.Down) && !previousKeyboard.IsKeyDown(Keys.Down))
            {
                _selectedOption = (_selectedOption + 1) % _menuOptions.Length;
            }
            else if (currentKeyboard.IsKeyDown(Keys.Up) && !previousKeyboard.IsKeyDown(Keys.Up))
            {
                _selectedOption = (_selectedOption - 1 + _menuOptions.Length) % _menuOptions.Length;
            }

            if (currentKeyboard.IsKeyDown(Keys.Enter) && !previousKeyboard.IsKeyDown(Keys.Enter))
            {
                return _selectedOption;
            }

            return -1;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            // Ajustar posição do background para começar em (0,0)
            Vector2 bgPosition = new Vector2(0, 0);
            spriteBatch.Draw(_backgroundTexture, bgPosition, Color.White);

            // Desenhar título
            _font.DrawText(spriteBatch, "PATH TO STARDOM", _titlePosition, Color.Gold, 3f);

            // Desenhar opções do menu
            for (int i = 0; i < _menuOptions.Length; i++)
            {
                Color color = (i == _selectedOption) ? _selectedColor : _normalColor;
                _font.DrawText(spriteBatch, _menuOptions[i], _optionPositions[i], color, 2f);

                // Desenhar indicador de seleção
                if (i == _selectedOption)
                {
                    Vector2 indicatorPos = new Vector2(_optionPositions[i].X - 30, _optionPositions[i].Y);
                    _font.DrawText(spriteBatch, ">", indicatorPos, _selectedColor, 2f);
                }
            }
        }
    }

    public class CreditsScreen
    {
        private Texture2D _backgroundTexture;
        private BitmapFont _font;
        private string[] _creditsText = {
        "PATH TO STARDOM",
        "",
        "DESENVOLVIDO POR:",
        "Rodrigo Dias",
        "Nuno Soares",
        "Joao Veloso",
        "",
        "Tecnicas de Desenvolvimento de Videojogos",
        "",
        "AGRADECIMENTOS ESPECIAIS:",
        "COMUNIDADE MONOGAME",
        "Pagina de ITCH.IO de Luiz Melo pelas Spritesheets",
        "",
        "PRESSIONE ENTER PARA VOLTAR"
    };

        public void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            _font = new BitmapFont(graphicsDevice);
            _backgroundTexture = CreateCreditsBackground(graphicsDevice);
        }

        private Texture2D CreateCreditsBackground(GraphicsDevice graphicsDevice)
        {
            Texture2D texture = new Texture2D(graphicsDevice, 1280, 720);
            Color[] data = new Color[1280 * 720];
            for (int i = 0; i < data.Length; i++)
                data[i] = Color.Black;
            texture.SetData(data);
            return texture;
        }

        public bool Update(KeyboardState currentKeyboard, KeyboardState previousKeyboard)
        {
            return currentKeyboard.IsKeyDown(Keys.Enter) && !previousKeyboard.IsKeyDown(Keys.Enter);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            // Desenhar background começando em (0,0)
            Vector2 bgPosition = new Vector2(0, 0);
            spriteBatch.Draw(_backgroundTexture, bgPosition, Color.White);

            // Desenhar texto dos créditos centralizado
            for (int i = 0; i < _creditsText.Length; i++)
            {
                Vector2 textPosition = new Vector2(640 - 100, 100 + i * 40); // Centralizado
                Color textColor = (i == 0) ? Color.Gold : Color.White; // Título em dourado
                float scale = (i == 0) ? 2.5f : 1.5f; // Título maior

                _font.DrawText(spriteBatch, _creditsText[i], textPosition, textColor, scale);
            }
        }
    }
}

