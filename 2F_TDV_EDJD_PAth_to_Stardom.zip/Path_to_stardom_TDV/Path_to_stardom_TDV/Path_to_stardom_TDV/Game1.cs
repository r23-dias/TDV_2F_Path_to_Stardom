﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace Path_to_stardom_TDV
{
    public enum GameState
    {
        MainMenu,
        Playing,
        Credits,
        Victory
    }

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private GameState _currentState;

        // Menu System
        private MainMenu _mainMenu;
        private CreditsScreen _creditsScreen;
        private VictoryScreen _victoryScreen;

        // Game Objects
        private Fighter player1;
        private Fighter player2;
        private StaticBackground _background;
        private Camera _camera;

        // Input
        private KeyboardState currentKeyboardState;
        private KeyboardState previousKeyboardState;

        private Song _menuMusic;
        private Texture2D _healthBarTexture;
        private BitmapFont _healthBarFont;

        private float _backgroundWidth;
        private float _leftLimit;
        private float _rightLimit;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            // Mantém sua resolução de 1280x720 mas em tela cheia
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.IsFullScreen = true;
            _graphics.ApplyChanges();

            _currentState = GameState.MainMenu;
        }

        protected override void Initialize()
        {
            // Inicializar sistema de menus
            _mainMenu = new MainMenu();
            _creditsScreen = new CreditsScreen();
            _victoryScreen = new VictoryScreen();

            // Inicializar objetos do jogo
            Vector2 player1StartPos = new Vector2(-320, 500);
            Vector2 player2StartPos = new Vector2(320, 590);

            // Calcular o ponto médio inicial entre os dois jogadores
            Vector2 cameraStartPos = new Vector2(
                (player1StartPos.X + player2StartPos.X) / 2f,
                (player1StartPos.Y + player2StartPos.Y) / 2f
            );

            _camera = new Camera(GraphicsDevice.Viewport, cameraStartPos);

            player1 = new Fighter("Player1", "MKing", player1StartPos, Color.White);
            player2 = new Fighter("Player2", "FWarrior", player2StartPos, Color.White);

            // Esconder hitboxes
            player1.ShowHitboxes = false;
            player2.ShowHitboxes = false;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            // Carregar conteúdo dos menus
            _mainMenu.LoadContent(Content, GraphicsDevice);
            _creditsScreen.LoadContent(Content, GraphicsDevice);
            _victoryScreen.LoadContent(Content, GraphicsDevice);

            _background = new StaticBackground(
                screenWidth: _graphics.PreferredBackBufferWidth,
                verticalOffset: -150 // Valores negativos = sobe, positivos = desce
            );
            _background.LoadContent(Content);

            // Calcular limites dos jogadores com base no fundo
            _backgroundWidth = _background.GetLayerWidth();
            _leftLimit = -_backgroundWidth;
            _rightLimit = _backgroundWidth * 2;

            _spriteBatch = new SpriteBatch(GraphicsDevice);
            player1.LoadContent(Content);
            player2.LoadContent(Content);

            // Carregar música do menu da pasta Sound
            _menuMusic = Content.Load<Song>("Sound/Musica de menu");

            // Configurar e iniciar a música do menu
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Volume = 0.5f; // Ajuste o volume conforme necessário (0.0f a 1.0f)
            MediaPlayer.Play(_menuMusic);
        }

        protected override void Update(GameTime gameTime)
        {
            previousKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();

            // Sair do jogo
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
                currentKeyboardState.IsKeyDown(Keys.Escape))
            {
                if (_currentState == GameState.MainMenu)
                    Exit();
                else
                    _currentState = GameState.MainMenu;
            }

            UpdateMusic();

            switch (_currentState)
            {
                case GameState.MainMenu:
                    UpdateMainMenu();
                    break;

                case GameState.Playing:
                    UpdateGame(gameTime);
                    break;

                case GameState.Credits:
                    UpdateCredits();
                    break;

                case GameState.Victory:
                    UpdateVictory(gameTime);
                    break;
            }

            base.Update(gameTime);
        }

        private void UpdateMusic()
        {
            switch (_currentState)
            {
                case GameState.MainMenu:
                case GameState.Credits:
                    // Tocar música do menu se não estiver tocando
                    if (MediaPlayer.State != MediaState.Playing ||
                        MediaPlayer.Queue.ActiveSong != _menuMusic)
                    {
                        MediaPlayer.IsRepeating = true;
                        MediaPlayer.Volume = 0.5f;
                        MediaPlayer.Play(_menuMusic);
                    }
                    break;

                case GameState.Playing:
                case GameState.Victory:
                    // Parar música do menu durante o jogo e tela de vitória
                    if (MediaPlayer.State == MediaState.Playing &&
                        MediaPlayer.Queue.ActiveSong == _menuMusic)
                    {
                        MediaPlayer.Stop();
                    }
                    break;
            }
        }

        private void UpdateMainMenu()
        {
            int selectedOption = _mainMenu.Update(currentKeyboardState, previousKeyboardState);

            switch (selectedOption)
            {
                case 0: // NOVO JOGO
                    _currentState = GameState.Playing;
                    break;

                case 1: // CREDITOS
                    _currentState = GameState.Credits;
                    break;

                case 2: // SAIR
                    Exit();
                    break;
            }
        }

        private void UpdateGame(GameTime gameTime)
        {
            player1.Update(gameTime, currentKeyboardState, previousKeyboardState, player2);
            player2.Update(gameTime, currentKeyboardState, previousKeyboardState, player1);

            ClampPlayerPosition(player1);
            ClampPlayerPosition(player2);

            // Player 1 atacando Player 2
            if (player1.IsAttacking && !player1.HasHit)
            {
                foreach (var attackHitbox in player1.AttackHitboxes)
                {
                    if (attackHitbox.Intersects(player2.Hitbox))
                    {
                        player2.TakeDamage(player1.AttackDamage);
                        player1.HasHit = true;
                        break;
                    }
                }
            }

            // Player 2 atacando Player 1
            if (player2.IsAttacking && !player2.HasHit)
            {
                foreach (var attackHitbox in player2.AttackHitboxes)
                {
                    if (attackHitbox.Intersects(player1.Hitbox))
                    {
                        player1.TakeDamage(player2.AttackDamage);
                        player2.HasHit = true;
                        break;
                    }
                }
            }

            // Verificar condições de vitória
            if (player1.IsDead && player1.DeathAnimationComplete)
            {
                _victoryScreen.SetWinner(2); // Player 2 venceu (passar int)
                _currentState = GameState.Victory;
            }
            else if (player2.IsDead && player2.DeathAnimationComplete)
            {
                _victoryScreen.SetWinner(1); // Player 1 venceu (passar int)
                _currentState = GameState.Victory;
            }

            // Atualizar câmera - CORREÇÃO AQUI
            _camera.Update(player1.Position, player2.Position);
        }

        private void ClampPlayerPosition(Fighter player)
        {
            Vector2 position = player.Position;
            position.X = MathHelper.Clamp(position.X, _leftLimit, _rightLimit);
            player.Position = position;
        }

        private void UpdateCredits()
        {
            if (_creditsScreen.Update(currentKeyboardState, previousKeyboardState))
            {
                _currentState = GameState.MainMenu;
            }
        }

        private void UpdateVictory(GameTime gameTime)
        {
            // Corrigir a ordem dos parâmetros: gameTime primeiro, depois os KeyboardStates
            int result = _victoryScreen.Update(gameTime, currentKeyboardState, previousKeyboardState);
            if (result == 1)
            {
                // Reinicia o jogo
                ResetGame();
                _currentState = GameState.MainMenu;
            }
        }
        private void ResetGame()
        {
            Vector2 player1StartPos = new Vector2(-320, 500);
            Vector2 player2StartPos = new Vector2(320, 500);

            Vector2 cameraStartPos = new Vector2(
                (player1StartPos.X + player2StartPos.X) / 2f,
                (player1StartPos.Y + player2StartPos.Y) / 2f
            );

            _camera = new Camera(GraphicsDevice.Viewport, cameraStartPos);
            player1 = new Fighter("Player1", "MKing", player1StartPos, Color.White);
            player2 = new Fighter("Player2", "FWarrior", player2StartPos, Color.White);

            // Esconder hitboxes
            player1.ShowHitboxes = false;
            player2.ShowHitboxes = false;

            player1.LoadContent(Content);
            player2.LoadContent(Content);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            switch (_currentState)
            {
                case GameState.MainMenu:
                    _spriteBatch.Begin();
                    _mainMenu.Draw(_spriteBatch);
                    _spriteBatch.End();
                    break;

                case GameState.Playing:
                    // Desenhar o jogo com transformação da câmera
                    _spriteBatch.Begin(
                        transformMatrix: _camera.TransformMatrix,
                        sortMode: SpriteSortMode.BackToFront
                    );
                    _background.Draw(_spriteBatch, _camera.Position);
                    player1.Draw(_spriteBatch, GraphicsDevice);
                    player2.Draw(_spriteBatch, GraphicsDevice);
                    _spriteBatch.End();

                    // Desenhar UI fixa (barras de vida) SEM transformação da câmera
                    _spriteBatch.Begin();
                    DrawHealthBars(_spriteBatch);
                    _spriteBatch.End();
                    break;

                case GameState.Credits:
                    _spriteBatch.Begin();
                    _creditsScreen.Draw(_spriteBatch);
                    _spriteBatch.End();
                    break;

                case GameState.Victory:
                    _spriteBatch.Begin();
                    _victoryScreen.Draw(_spriteBatch);
                    _spriteBatch.End();
                    break;
            }

            base.Draw(gameTime);
        }

        private void DrawHealthBars(SpriteBatch spriteBatch)
        {
            // Criar textura para as barras se não existir
            if (_healthBarTexture == null)
            {
                _healthBarTexture = new Texture2D(GraphicsDevice, 1, 1);
                _healthBarTexture.SetData(new[] { Color.White });
            }

            // Criar fonte se não existir
            if (_healthBarFont == null)
            {
                _healthBarFont = new BitmapFont(GraphicsDevice);
            }

            // Configurações das barras
            int barWidth = 300;
            int barHeight = 20;
            int marginFromEdge = 50;
            int marginFromTop = 30;

            // === BARRA DO PLAYER 1 (ESQUERDA) ===
            Vector2 player1BarPos = new Vector2(marginFromEdge, marginFromTop);

            // Fundo da barra (vermelho escuro)
            Rectangle player1Background = new Rectangle(
                (int)player1BarPos.X,
                (int)player1BarPos.Y,
                barWidth,
                barHeight
            );

            // Barra de vida atual (verde/amarelo dependendo da vida)
            float player1HealthPercent = player1.Health / 100f;
            int player1HealthWidth = (int)(barWidth * player1HealthPercent);
            Rectangle player1Health = new Rectangle(
                (int)player1BarPos.X,
                (int)player1BarPos.Y,
                player1HealthWidth,
                barHeight
            );

            // Cor da barra baseada na vida restante
            Color player1BarColor = GetHealthBarColor(player1HealthPercent);

            // Desenhar barra do Player 1
            spriteBatch.Draw(_healthBarTexture, player1Background, Color.DarkRed);
            spriteBatch.Draw(_healthBarTexture, player1Health, player1BarColor);
            DrawHealthBarBorder(spriteBatch, player1Background);

            // Nome do Player 1
            Vector2 player1NamePos = new Vector2(player1BarPos.X, player1BarPos.Y - 25);
            _healthBarFont.DrawText(spriteBatch, "PLAYER 1", player1NamePos, Color.White, 1.5f);

            // === BARRA DO PLAYER 2 (DIREITA) ===
            Vector2 player2BarPos = new Vector2(
                _graphics.PreferredBackBufferWidth - marginFromEdge - barWidth,
                marginFromTop
            );

            // Fundo da barra (vermelho escuro)
            Rectangle player2Background = new Rectangle(
                (int)player2BarPos.X,
                (int)player2BarPos.Y,
                barWidth,
                barHeight
            );

            // Barra de vida atual - Para Player 2, a barra diminui da direita para esquerda
            float player2HealthPercent = player2.Health / 100f;
            int player2HealthWidth = (int)(barWidth * player2HealthPercent);
            Rectangle player2Health = new Rectangle(
                (int)player2BarPos.X + (barWidth - player2HealthWidth), // Começa da direita
                (int)player2BarPos.Y,
                player2HealthWidth,
                barHeight
            );

            // Cor da barra baseada na vida restante
            Color player2BarColor = GetHealthBarColor(player2HealthPercent);

            // Desenhar barra do Player 2
            spriteBatch.Draw(_healthBarTexture, player2Background, Color.DarkRed);
            spriteBatch.Draw(_healthBarTexture, player2Health, player2BarColor);
            DrawHealthBarBorder(spriteBatch, player2Background);

            // Nome do Player 2 (alinhado à direita)
            Vector2 player2NamePos = new Vector2(player2BarPos.X + barWidth - 120, player2BarPos.Y - 25);
            _healthBarFont.DrawText(spriteBatch, "PLAYER 2", player2NamePos, Color.White, 1.5f);

            // === TIMER NO CENTRO (OPCIONAL) ===
            Vector2 timerPos = new Vector2(
                _graphics.PreferredBackBufferWidth / 2 - 30,
                marginFromTop - 10
            );
            _healthBarFont.DrawText(spriteBatch, "99", timerPos, Color.Yellow, 2f);
        }

        private Color GetHealthBarColor(float healthPercent)
        {
            if (healthPercent > 0.6f)
                return Color.Green;      // Verde quando vida > 60%
            else if (healthPercent > 0.3f)
                return Color.Yellow;     // Amarelo quando vida entre 30-60%
            else
                return Color.Orange;     // Laranja quando vida < 30%
        }


        private void DrawHealthBarBorder(SpriteBatch spriteBatch, Rectangle barRect)
        {
            int borderThickness = 2;

            // Borda superior
            spriteBatch.Draw(_healthBarTexture,
                new Rectangle(barRect.X - borderThickness, barRect.Y - borderThickness,
                             barRect.Width + 2 * borderThickness, borderThickness),
                Color.White);

            // Borda inferior
            spriteBatch.Draw(_healthBarTexture,
                new Rectangle(barRect.X - borderThickness, barRect.Y + barRect.Height,
                             barRect.Width + 2 * borderThickness, borderThickness),
                Color.White);

            // Borda esquerda
            spriteBatch.Draw(_healthBarTexture,
                new Rectangle(barRect.X - borderThickness, barRect.Y,
                             borderThickness, barRect.Height),
                Color.White);

            // Borda direita
            spriteBatch.Draw(_healthBarTexture,
                new Rectangle(barRect.X + barRect.Width, barRect.Y,
                             borderThickness, barRect.Height),
                Color.White);
        }
    }
}
